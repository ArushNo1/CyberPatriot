BANR()
{
	echo ""
	echo ""
	echo "     ######################################################## "
	echo "     #  Sample CIS Linux Build Kit for                      # "
	echo "     #  Red Hat Enterprise Linux 7                          # "
	echo "     #  This Linux Build Kit works in conjunction with the  # "
	echo "     #  CIS Red Hat Enterprise Linux 7 Benchmark v3.0.1     # "
	echo "     #  This script is the property of:                     # "
	echo "     #  Center for Internet Security (CIS)                  # "
	echo "     ######################################################## "
	echo ""
	echo ""
}
# End of print bannor to Screen