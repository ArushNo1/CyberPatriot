CIS Red Hat Enterprise Linux 7 Benchmark v3.0.1
Sample Linux Build Kit

This Linux Build kit contains a sub-set of the
functions used to remediate a Red Hat Enterprise Linux 7
system in accordence with the guidence in the
CIS Red Hat Enterprise Linux 7 Benchmark v3.0.1

There is a exclusion_list.txt file included.  
Recomendation numbers added to this file will not
be run as part of the execution of the Linux
build kit

To run this sample build kit, untar the gzip tar file
and execute SAMPLE_RHEL7_BMv3.0.1_BK.sh